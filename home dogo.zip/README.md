# 🏡 Home Dojo

A warm, ClassDojo-style app for the home: merits & demerits, recurring chores, a rewards shop, weekly achievements and weekly summaries. Multiple children per family, multiple parents per family, real accounts.

## Run it on your computer
Needs **Node.js 22.13 or newer** (https://nodejs.org). No `npm install` is required — there are no dependencies.

    node server.js
    # open http://localhost:3000

Click **Create a family**, then add your children. Your partner clicks **Join with a code** and uses the invite code shown at the top of the page.

## Put it online with your own domain
You need four things:
1. **A host that runs Node (or Docker) and has a persistent disk.** Examples: Render, Railway, Fly.io, or a small VPS (DigitalOcean, Hetzner, etc.). Typically $5–10/month. Free tiers usually wipe the disk, which would delete your family data.
2. **A domain name** from any registrar (Namecheap, Cloudflare, GoDaddy…), roughly $10–15/year. Point it at the host (the host's dashboard shows the DNS records to add).
3. **HTTPS.** Render/Railway/Fly give you this automatically; on a VPS use Caddy or nginx + Let's Encrypt.
4. **Environment settings:**
   - `NODE_ENV=production` (makes login cookies HTTPS-only)
   - `DATA_DIR=/data` (a folder on the persistent disk — your database lives in `homedojo.db` there)
   - `PORT` is usually set by the host

Docker: `docker build -t homedojo .` then `docker run -p 3000:3000 -v homedojo-data:/data homedojo`

## Back up your data
Everything is in one file: `DATA_DIR/homedojo.db`. Copy it regularly (stop the app first, or copy the `-wal` file too).

## What's included
- Email + password accounts (passwords hashed with scrypt), 30-day login sessions, sign out
- Families with an invite code so both parents share the same data
- Kid view (no merit/demerit buttons) for handing the device to a child
- ~50 merits, ~30 demerits, custom ones, levels, achievement badges
- Recurring chores (daily/weekly/once) with parent approval
- Rewards shop, weekly achievements shelf + history, weekly summaries
- Sync across phones (refreshes every 5 seconds)

## Not included yet (sensible next steps)
- Password reset and email verification (needs an email service such as Resend or Postmark)
- A PIN to lock parent mode on a shared device
- Editing the merit/demerit lists and point values inside the app
- A privacy policy / terms page — recommended before you invite other families, because the app stores children's first names and behaviour records. Check the rules that apply where you operate (e.g. Nigeria's NDPA 2023).
- Rate limiting is basic and in-memory; add a proper limiter or a service like Cloudflare if you open it to the public.
